export const initialCategories = [
  { id: 1, name: 'Dried Fruits', products: 24, icon: '🍇', description: 'Natural dried fruits' },
  { id: 2, name: 'Nuts', products: 18, icon: '🥜', description: 'Premium quality nuts' },
  { id: 3, name: 'Gift Packs', products: 12, icon: '🎁', description: 'Special gift boxes' }
];
