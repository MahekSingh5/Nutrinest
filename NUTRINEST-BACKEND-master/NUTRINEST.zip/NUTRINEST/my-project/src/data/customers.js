export const initialCustomers = [
  { id: 1, name: 'Rajesh Kumar', email: 'rajesh@example.com', phone: '+91 98765 43210', orders: 12, totalSpent: 15600, joined: '2023-05-15' },
  { id: 2, name: 'Priya Sharma', email: 'priya@example.com', phone: '+91 98765 43211', orders: 8, totalSpent: 9200, joined: '2023-07-22' },
  { id: 3, name: 'Amit Patel', email: 'amit@example.com', phone: '+91 98765 43212', orders: 15, totalSpent: 21400, joined: '2023-03-10' },
  { id: 4, name: 'Neha Gupta', email: 'neha@example.com', phone: '+91 98765 43213', orders: 10, totalSpent: 12800, joined: '2023-06-18' },
  { id: 5, name: 'Vikram Singh', email: 'vikram@example.com', phone: '+91 98765 43214', orders: 7, totalSpent: 8900, joined: '2023-08-05' },
  { id: 6, name: 'Anjali Desai', email: 'anjali@example.com', phone: '+91 98765 43215', orders: 14, totalSpent: 18600, joined: '2023-04-20' },
  { id: 7, name: 'Arjun Nair', email: 'arjun@example.com', phone: '+91 98765 43216', orders: 9, totalSpent: 11200, joined: '2023-09-12' },
  { id: 8, name: 'Divya Mehta', email: 'divya@example.com', phone: '+91 98765 43217', orders: 11, totalSpent: 14500, joined: '2023-02-28' }
];
